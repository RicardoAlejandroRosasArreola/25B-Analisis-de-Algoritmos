import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from umap import UMAP
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics.pairwise import euclidean_distances
import os

# Configuración de estilo
plt.style.use('default')
sns.set_palette("husl")

class FashionMNISTAnalyzer:
    def __init__(self):
        self.df = None
        self.X = None
        self.y = None
        self.umap_2d = None
        self.umap_results = None
        
    def load_data(self, csv_path):
        """Cargar datos desde archivo CSV"""
        print("Cargando datos...")
        self.df = pd.read_csv(csv_path)
        
        # Separar características y etiquetas
        self.y = self.df.iloc[:, 0].values  # Primera columna son las etiquetas
        self.X = self.df.iloc[:, 1:].values  # Resto son píxeles
        
        print(f"Datos cargados: {self.X.shape[0]} muestras, {self.X.shape[1]} características")
        print(f"Distribución de etiquetas: {np.unique(self.y, return_counts=True)}")
        
    def apply_umap_full(self, n_samples=5000):
        """Aplicar UMAP al conjunto completo (muestreado para eficiencia)"""
        print("Aplicando UMAP al conjunto completo...")
        
        # Muestrear para hacerlo manejable
        if len(self.X) > n_samples:
            indices = np.random.choice(len(self.X), n_samples, replace=False)
            X_sample = self.X[indices]
            y_sample = self.y[indices]
        else:
            X_sample = self.X
            y_sample = self.y
        
        # Estandarizar datos
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X_sample)
        
        # Aplicar UMAP
        self.umap_2d = UMAP(n_components=2, random_state=42, n_neighbors=15, min_dist=0.1)
        self.umap_results = self.umap_2d.fit_transform(X_scaled)
        
        self.visualize_full_dataset(self.umap_results, y_sample)
        return self.umap_results, y_sample
    
    def visualize_full_dataset(self, umap_results, labels):
        """Visualizar resultados de UMAP para el conjunto completo"""
        plt.figure(figsize=(12, 8))
        
        # Diccionario de etiquetas Fashion-MNIST
        label_names = {
            0: 'T-shirt/top', 1: 'Trouser', 2: 'Pullover', 3: 'Dress', 
            4: 'Coat', 5: 'Sandal', 6: 'Shirt', 7: 'Sneaker', 8: 'Bag', 9: 'Ankle boot'
        }
        
        scatter = plt.scatter(umap_results[:, 0], umap_results[:, 1], 
                             c=labels, cmap='tab10', alpha=0.7, s=10)
        plt.colorbar(scatter, label='Categorías')
        plt.title('UMAP - Fashion-MNIST (Visualización 2D)')
        plt.xlabel('UMAP 1')
        plt.ylabel('UMAP 2')
        
        # Crear leyenda personalizada
        handles, _ = scatter.legend_elements()
        plt.legend(handles, [label_names[i] for i in range(10)], 
                  title="Categorías", bbox_to_anchor=(1.05, 1), loc='upper left')
        
        plt.tight_layout()
        # GUARDAR EN CARPETAS
        plt.savefig('results/umap_full_dataset.png', dpi=300, bbox_inches='tight')
        plt.savefig('images/umap_full_dataset.png', dpi=300, bbox_inches='tight')
        print("✅ Gráfica guardada en: results/ e images/")
        plt.show()
    
    def analyze_cluster(self, cluster_label, n_samples=1000):
        """Analizar un cluster específico y encontrar subclusters"""
        print(f"Analizando cluster {cluster_label}...")
        
        # Filtrar instancias del cluster
        cluster_indices = np.where(self.y == cluster_label)[0]
        
        if len(cluster_indices) > n_samples:
            cluster_indices = np.random.choice(cluster_indices, n_samples, replace=False)
        
        X_cluster = self.X[cluster_indices]
        
        # Aplicar UMAP al cluster
        scaler = StandardScaler()
        X_cluster_scaled = scaler.fit_transform(X_cluster)
        
        umap_cluster = UMAP(n_components=2, random_state=42, n_neighbors=10, min_dist=0.1)
        cluster_results = umap_cluster.fit_transform(X_cluster_scaled)
        
        # Encontrar subclusters usando clustering
        kmeans = KMeans(n_clusters=3, random_state=42)
        subcluster_labels = kmeans.fit_predict(cluster_results)
        
        self.visualize_subclusters(cluster_results, subcluster_labels, cluster_label, X_cluster)
        
        return cluster_results, subcluster_labels, X_cluster
    
    def visualize_subclusters(self, umap_results, subcluster_labels, cluster_label, X_data):
        """Visualizar subclusters dentro de un cluster principal"""
        label_names = {
            0: 'T-shirt/top', 1: 'Trouser', 2: 'Pullover', 3: 'Dress', 
            4: 'Coat', 5: 'Sandal', 6: 'Shirt', 7: 'Sneaker', 8: 'Bag', 9: 'Ankle boot'
        }
        
        # FIGURA 1: Gráfico de puntos de subclusters
        plt.figure(figsize=(12, 8))
        scatter = plt.scatter(umap_results[:, 0], umap_results[:, 1], 
                            c=subcluster_labels, cmap='viridis', alpha=0.7, s=40)
        plt.title(f'Subclusters en {label_names[cluster_label]} (Categoría {cluster_label})', 
                fontsize=14, fontweight='bold')
        plt.xlabel('UMAP Componente 1')
        plt.ylabel('UMAP Componente 2')
        plt.grid(True, alpha=0.3)
        plt.colorbar(scatter, label='Subcluster')
        plt.tight_layout()
        # GUARDAR EN CARPETAS
        plt.savefig(f'results/subclusters_category_{cluster_label}.png', dpi=300, bbox_inches='tight')
        plt.savefig(f'images/subclusters_category_{cluster_label}.png', dpi=300, bbox_inches='tight')
        print(f"✅ Gráfico de subclusters guardado en carpetas: {cluster_label}")
        plt.show()
    
        # FIGURA 2: Imágenes representativas
        self.display_representative_images(X_data, subcluster_labels, cluster_label)
    
    def display_representative_images(self, X_data, subcluster_labels, cluster_label):
        """Mostrar imágenes representativas de cada subcluster"""
        unique_subclusters = np.unique(subcluster_labels)
        
        label_names = {
            0: 'T-shirt/top', 1: 'Trouser', 2: 'Pullover', 3: 'Dress', 
            4: 'Coat', 5: 'Sandal', 6: 'Shirt', 7: 'Sneaker', 8: 'Bag', 9: 'Ankle boot'
        }
        
        images_per_row = 3
        total_images = len(unique_subclusters) * images_per_row
        
        fig, axes = plt.subplots(len(unique_subclusters), images_per_row, 
                                figsize=(12, 4 * len(unique_subclusters)))
        
        if len(unique_subclusters) == 1:
            axes = [axes]
        
        for i, subcluster in enumerate(unique_subclusters):
            subcluster_indices = np.where(subcluster_labels == subcluster)[0]
            X_subcluster = X_data[subcluster_indices]
            
            # Calcular centroide
            centroid = np.mean(X_subcluster, axis=0)
            
            # Encontrar imágenes más cercanas al centroide
            distances = euclidean_distances(X_subcluster, [centroid]).flatten()
            closest_indices = np.argsort(distances)[:images_per_row]
            
            for j, idx in enumerate(closest_indices):
                img = X_subcluster[idx].reshape(28, 28)
                axes[i][j].imshow(img, cmap='gray')
                axes[i][j].set_title(f'Subcluster {subcluster}\nImagen {j+1}')
                axes[i][j].axis('off')
        
        plt.suptitle(f'Imágenes representativas - {label_names[cluster_label]}', fontsize=16)
        plt.tight_layout()
        # GUARDAR EN CARPETAS
        plt.savefig(f'results/representative_images_{cluster_label}.png', dpi=300, bbox_inches='tight')
        plt.savefig(f'images/representative_images_{cluster_label}.png', dpi=300, bbox_inches='tight')
        print(f"✅ Imágenes representativas guardadas en carpetas: {cluster_label}")
        plt.show()

def main():
    # Crear carpetas si no existen
    os.makedirs('results', exist_ok=True)
    os.makedirs('images', exist_ok=True)
    
    analyzer = FashionMNISTAnalyzer()
    
    # Cargar datos
    csv_path = 'data/fashion-mnist.csv'
    
    if not os.path.exists(csv_path):
        print(f"Error: No se encuentra el archivo {csv_path}")
        print("Por favor, asegúrate de que el archivo CSV esté en la carpeta data/")
        return
    
    analyzer.load_data(csv_path)
    
    # Análisis del conjunto completo
    umap_results, labels = analyzer.apply_umap_full(n_samples=5000)
    
    # Analizar MÚLTIPLES clusters específicos
    clusters_to_analyze = [5, 7, 0]  # Sandals, Sneakers, T-shirts
    
    for cluster_id in clusters_to_analyze:
        print(f"\n" + "="*50)
        print(f"Analizando subclusters para categoría {cluster_id}")
        print("="*50)
        cluster_results, subcluster_labels, X_cluster = analyzer.analyze_cluster(cluster_id)
    
    print("\n🎉 Análisis completado! Revisa los archivos en las carpetas 'results/' e 'images/'")

if __name__ == "__main__":
    main()